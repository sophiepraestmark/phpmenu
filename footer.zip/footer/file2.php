<!doctype html>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
</head>

<body>

<!-- Nedenfor indsætter jeg min menu i én linje - ved hjælp af PHP-  istedet for at skule kode den fra bunden i html på alle siderne! Jeg bruger php funktionen "include" til dette, og inkludere altså menuen fra en seperat php fil!! -->
<?php include 'menu.php'; ?>

<h1>Page 2</h1>
<p>Dette er side 2 af 4</p>

<!-- Nedenfor inkluderer jeg min footer, på samme måde som jeg har inkluderet menuen via. php -->
<?php include 'footer.php'; ?>

<!-- Detter er min footer som er kodet i html, og indsættes på hver side via php funktionen "include"-->
<hr>
<p>Foooooooooooooooooooooooooooooooooooooooooooooter</p>
</body>
</html>
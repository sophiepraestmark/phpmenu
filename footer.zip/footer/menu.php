<!-- Nedenfor linker jeg til mit eksterne stylesheet -->
 <link rel="stylesheet" href="style.css">

<!-- I min kode nedenfor, har jeg inkluderet php objektet "curpage", så der vides hvilken side der er aktiv i mine menu links længere nede!-->

<?php

// echo $_SERVER['PHP_SELF'];
$curpage = basename($_SERVER['PHP_SELF']);
echo $curpage.PHP_EOL;
?>

<!-- Nedenfor har jeg opbygget min menu i html, i en liste! Funktionen "if" bruges i forbindelse med objektet "$curpage", som fortæller hvilken side der er aktiv! Funktionen "echo 'class=active'" bruges til at fortælle hvilke værdier der skal hentes fra mit eksterne stylesheet, således at det aktive link bliver stylet!-->


<ul>
    <li><a href="file1.php" <?php if ($curpage === 'file1.php') {echo 'class="active"';} ?>>Page 1</a></li>
    <li><a href="file2.php" <?php if ($curpage === 'file2.php') {echo 'class="active"';} ?>>Page 2</a></li>
    <li><a href="file3.php" <?php if ($curpage === 'file3.php') {echo 'class="active"';} ?>>Page 3</a></li>
    <li><a href="file4.php" <?php if ($curpage === 'file4.php') {echo 'class="active"';} ?>>Page 4</a></li>
</ul>
